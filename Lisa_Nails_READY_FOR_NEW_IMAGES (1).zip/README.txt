LISA NAILS — COMPLETE WEBSITE

This package includes the multi-page Lisa Nails home-service website.
Contact: 08037549246

Pages: Home, Services, Gallery, Designs, About, Booking, Contact.

Removed: Master Admin and social media section.
Added: Why Choose Lisa Nails, before-and-after area ready for genuine client photos, client feedback area, home-service area, floating WhatsApp booking button, and improved booking validation.

IMPORTANT: The review cards are clearly marked as sample placeholders and should be replaced with genuine customer reviews before publishing as testimonials. The before-and-after area should use genuine matching before/after client photos; existing nail photos are not presented as real transformations.

Netlify: upload this ZIP with index.html at the root.
