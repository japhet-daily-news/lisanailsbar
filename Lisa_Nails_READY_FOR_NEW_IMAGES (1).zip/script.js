const menu=document.querySelector('.menu');const nav=document.querySelector('.nav nav');menu?.addEventListener('click',()=>{if(!nav)return;nav.classList.toggle('open')});
